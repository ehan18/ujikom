@extends('layouts.test')

@section('content')
<div>
Hello ini section
</div>
@endsection
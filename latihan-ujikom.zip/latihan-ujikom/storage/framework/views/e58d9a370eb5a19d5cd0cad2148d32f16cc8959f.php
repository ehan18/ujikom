

<?php $__env->startSection('title', 'Laporan Keuangan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <h2 class="page-title">Laporan Transaksi</h2>
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <form id="lap_input" class="d-flex">
                            <div class="col-md-4">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label class="control-label">Tanggal Awal</label>
                                        <input type="date" id="tgl_awal_input" pattern="\d{4}-\d{2}-\d{2}" name="tanggal_masuk" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label class="control-label">Tanggal Akhir</label>
                                        <input type="date" id="tgl_akhir_input" pattern="\d{4}-\d{2}-\d{2}" name="tanggal_keluar" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="btn btn-primary"  id="btn_filter" style="margin-top: 1.7rem;">
                                    Filter
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="container-fluid">
                        <div class="row">
                            <table id="lap_trans" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Konsumen</th>
                                        <th>Nama Paket</th>
                                        <th>Tipe Pembayaran</th>
                                        <th>Status</th>
                                        <th>Berat</th>
                                        <th>Tanggal Masuk</th>
                                        <th>Tanggal Keluar</th>
                                        <th>Status Bayar</th>
                                        <th>Diskon</th>
                                        <th>Total Bayar</th>
                                        <th>Karyawan</th>
                                        <th>Keterangan</th>
                                        <th></th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script>
    $(document).ready(function(){
        var lap_datatable = $("#lap_trans").DataTable();

        $('#btn_filter').click(function(){
            var tgl_awal = $('#tgl_awal_input').val();
            var tgl_akhir = $('#tgl_akhir_input').val();

        // console.log(tgl_masuk, tgl_keluar);
        //     $.ajax({
        //         url: "<?php echo e(route('laporan.transaksi.ajax')); ?>",
        //         type: "POST",
        //         data: {
        //             "_token": "<?php echo e(csrf_token()); ?>",
        //             "tanggal_awal": tgl_awal,
        //             "tanggal_akhir": tgl_akhir
        //         },
        //         success: function(response){
        //             console.log(response);
        //         }
        //     });
        // });

        var tgl_awal = "2023-02-10"
        var tgl_akhir = "2023-02-17"

        $('#lap_trans').DataTable({
            proccesing: true,
            dataSrc: "data",
            ajax: {
                url: "<?php echo e(route('laporan.transaksi.ajax')); ?>",
                type: "POST",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "tanggal_awal": tgl_awal,
                    "tanggal_keluar": tgl_keluar,
                }
            }
        });
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RPL23\projects\latihan-ujikom\resources\views/laporan/transaksi.blade.php ENDPATH**/ ?>
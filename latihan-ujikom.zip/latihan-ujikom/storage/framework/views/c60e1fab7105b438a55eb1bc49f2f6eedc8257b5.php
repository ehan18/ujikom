
<?php $__env->startSection('title','Data Karyawan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">

						<h2 class="page-title">Kelola Data Karyawan</h2>

						<!-- Zero Configuration Table -->
						<div class="panel panel-default">
							<div class="panel-body">
							<a style="margin-bottom:12px;" href="karyawan/create" class="btn btn-primary">tambah karyawan</a>
								<table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr>
                                            <th>Kode karyawan</th>
											<th>Nama</th>
											<th>Alamat</th>
											<th>Nomor Telp</th>
											<th>Email</th>
											<th>Bergabung</th>
											<th></th>
										</tr>
									</thead>
									<tfoot>
										<tr>
                                            <th>Kode Karyawan</th>
										    <th>Nama</th>
											<th>Alamat</th>
											<th>Nomor Telp</th>
											<th>Email</th>
											<th>Bergabung</th>
											<th></th>
										</tr>
									</tfoot>
									<tbody>
                                        <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
                                        <td><?php echo e($kary->kode_user); ?></td>
									    <td><?php echo e($kary->name); ?></td>
										<td><?php echo e($kary->alamat); ?></td>
										<td><?php echo e($kary->no_telp); ?></td>
										<td><?php echo e($kary->email); ?></td>
										<td><?php echo e($kary->created_at->diffForHumans()); ?></td>
										<td>
										<div class="dropdown">
                                        <i class="dropdown-toggle glyphicon glyphicon-option-vertical" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                          
                                        </i>
                                       <ul style="margin-left:-10vw;" class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                        <li>
										      <a href="#">
										          <i class="glyphicon glyphicon-pencil"></i>
											      </i>Ubah
											  </a>
										   </li>
										   <li>
										      <form action="<?php echo e(route('karyawan.destroy', $kons->id)); ?>" method="POST">
											      <?php echo csrf_field(); ?>
												  <?php echo method_field('DELETE'); ?>

												  <button onclick="return deleteFunction()" type="submit">
												  <i class="glyphicon glyphicon-trash"></i>
											      </i>Hapus
												  </button> 
											  </form>
											  
										   </li>
                                       </ul>
                                     </div>
										</td>
									</tr>	

										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
								</table>

								

							</div>
						</div>

				

					</div>
				</div>

			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RPL23\projects\latihan-ujikom\resources\views/karyawan/index.blade.php ENDPATH**/ ?>
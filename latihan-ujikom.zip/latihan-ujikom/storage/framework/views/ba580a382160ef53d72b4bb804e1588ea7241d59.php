

<?php $__env->startSection('title', 'Tambah Data karyawan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
						<h2 class="page-title">Tambah Data Karyawan</h2>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-default">
									
									<div class="panel-body">
										<form method="post" action="<?php echo e(route('karyawan.store')); ?>" class="form-horizontal">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-md-6">
                                                <div class="form-group">
												<label class="col-sm-2 control-label">Kode Karyawan</label>
												<div class="col-sm-10">
													<input type="text" readonly value="<?php echo e($kode); ?>" name="kode_karyawan" class="form-control">
                                                </div>
</div>
                                                </div>
                                                <div class="col-md-6">
                                                <div class="form-group">
												<label class="col-sm-2 control-label">Nama</label>
												<div class="col-sm-10">
													<input type="text" name="nama" class="form-control">
                                                </div>
</div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                <div class="form-group">
												<label class="col-sm-2 control-label">Email</label>
												<div class="col-sm-10">
													<input type="text" name="email" class="form-control">
                                                </div>
</div>
                                                </div>
                                                <div class="col-md-6">
                                                <div class="form-group">
												<label class="col-sm-2 control-label">No_Telp</label>
												<div class="col-sm-10">
													<input type="number" name="no_telp" class="form-control">
                                                </div>
</div>                                      
</div>
                                                <div class="col-md-6">
                                                <div class="form-group">
												<label class="col-sm-2 control-label">Alamat</label>
												<div class="col-sm-10">
													<textarea name="alamat" class="form-control" rows="5"></textarea>
                                                </div>
</div>                                      
												<div class="col-sm-8 col-sm-offset-2">
													<a class="btn btn-default"  href="karyawan" type="submit">Batal</a>
													<a class="btn btn-primary" type="submit">Simpan</a>
												</div>
											</div>

										</form>

									</div>
								</div>
							</div>
							
						</div>
						
						

					</div>
				</div>
				
				

			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RPL23\projects\latihan-ujikom\resources\views/karyawan/create.blade.php ENDPATH**/ ?>